public class Test {
  public static void main(String[] args) {
    MobilePhone mp = new MobilePhone("HUAWEIMate30", "16945678999", 3380);
    mp.display();
  }
}
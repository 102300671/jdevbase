public class Main {
  public static void main(String[] args) {
    Worker worker = new Worker("Worker Zhang", 28, 8888.0, "SeniorEngineer");
    worker.display();
  }
}
package lab.lab10.Student;

public class Student {
	private String name;
	private double grade;
	private int age;
	public Student(String name, int age, double grade) {
		this.name = name;
		this.grade = grade;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGrade() {
		return grade;
	}
	public void setGrade(double grade) {
		this.grade = grade;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}

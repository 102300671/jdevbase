package lab.lab08.Animal;

public class Food {
	private int weight;
	public Food(int weight) {
		this.weight = weight;
	}
	public int getWeight() {
		return weight;
	}
}

package lab.lab08.Animal;

public class Animal {
	public void eat(Food food) {
		System.out.printf("It's time to eat %s.%n", food);
	}
}

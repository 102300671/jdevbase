package lab.lab09.PersonInterface;

public abstract class Person {
	private String name;
	public Person() {
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
}

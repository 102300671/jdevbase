package lab.lab09.PersonInterface;

public interface Soundable {
	void sound();
}

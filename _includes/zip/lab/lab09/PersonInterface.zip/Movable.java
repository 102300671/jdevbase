package lab.lab09.PersonInterface;

public interface Movable {
	void move();  
}

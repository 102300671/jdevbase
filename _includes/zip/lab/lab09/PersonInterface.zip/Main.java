package lab.lab09.PersonInterface;

public class Main {
	public static void main(String[] args) {

		Teacher t1=new Teacher();

		Worker w1=new Worker();

        	t1.move();

        	w1.move();

        	t1.sound();

        	w1.sound();

    }
}
